require('@nomicfoundation/hardhat-toolbox');
require('dotenv').config();

const ALCHEMY = process.env.ALCHEMY_RPC || '';
const GOERLI_RPC = process.env.GOERLI_RPC || '';
const PRIVATE_KEY = process.env.DEPLOYER_KEY || '';

module.exports = {
  solidity: '0.8.19',
  networks: {
    localhost: {
      url: 'http://127.0.0.1:8545'
    },
    goerli: {
      url: GOERLI_RPC,
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    },
    mainnet: {
      url: ALCHEMY,
      accounts: PRIVATE_KEY ? [PRIVATE_KEY] : []
    },
    hardhat: {
      forking: {
        url: ALCHEMY || GOERLI_RPC || '',
        blockNumber: undefined
      }
    }
  },
  etherscan: {
    apiKey: process.env.ETHERSCAN_API || ''
  }
};
