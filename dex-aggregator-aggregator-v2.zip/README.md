# Dex Aggregator — Aggregator Contract + Auto-deploy Hardhat Project

This repository contains a minimal aggregator smart contract (SimpleAggregator) and Hardhat scripts to compile, test, and deploy.

**Important:** This project is a starting/demo scaffold. DO NOT use this contract as-is on mainnet without a security audit and necessary feature hardening (fee handling, permit integration, slippage checks, comprehensive tests).

## What's included
- `contracts/SimpleAggregator.sol` — main contract
- `contracts/DummyRouter.sol` — test dummy router used in unit tests
- `scripts/deploy.js` — deploy script (Hardhat)
- `scripts/verify.js` — helper for etherscan verification
- `test/SimpleAggregator.test.js` — basic unit test
- `hardhat.config.js` — network config using .env
- `.env.example` — example env vars
- `package.json` — scripts to run tests, compile, deploy

## Quick start (local)
1. Clone and install dependencies:
   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env` and fill your RPC keys and private key.

3. Compile:
   ```bash
   npx hardhat compile
   ```

4. Run tests:
   ```bash
   npx hardhat test
   ```

5. Start a local node (optional):
   ```bash
   npx hardhat node
   ```

6. Deploy to local node:
   ```bash
   npx hardhat run --network localhost scripts/deploy.js
   ```

7. Deploy to Goerli / Mainnet (ensure .env set):
   ```bash
   npm run deploy:goerli
   npm run deploy:mainnet
   ```

## Security notes
- Only allow trusted router addresses.
- Do not enable arbitrary delegatecalls or exec patterns.
- Add slippage and deadline enforcement in off-chain calldata builder.
- Get a professional audit before mainnet usage.


## AggregatorV2 additions
- `contracts/AggregatorV2.sol` - extended aggregator with multicall, fee-on-top, permit helper and meta-tx support
- `contracts/DummyERC20.sol` - ERC20 for testing
- `contracts/DummyRouterV2.sol` - dummy router used in tests
- `scripts/deployAggregator.js` - deploy aggregator + dummy router + dummy token (local testing)
- `test/AggregatorV2.test.js` - unit tests for multicall and fee
