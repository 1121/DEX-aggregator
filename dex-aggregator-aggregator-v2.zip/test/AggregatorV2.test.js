const { expect } = require('chai');
const { ethers } = require('hardhat');

describe('AggregatorV2', function () {
  let Aggregator, aggregator, owner, user, feeRecipient;
  let DummyRouter, dummyRouter, DummyToken, dummyToken;

  beforeEach(async function () {
    [owner, user, feeRecipient] = await ethers.getSigners();

    Aggregator = await ethers.getContractFactory('AggregatorV2');
    aggregator = await Aggregator.deploy(30, feeRecipient.address); // 0.3% fee
    await aggregator.waitForDeployment();

    DummyRouter = await ethers.getContractFactory('DummyRouterV2');
    dummyRouter = await DummyRouter.deploy();
    await dummyRouter.waitForDeployment();

    DummyToken = await ethers.getContractFactory('DummyERC20');
    dummyToken = await DummyToken.deploy('Dummy', 'DUM');
    await dummyToken.waitForDeployment();

    // mint tokens to dummy router so it can transfer tokens to aggregator during swap
    await dummyToken.mint(dummyRouter.target, ethers.parseUnits('10000', 18));

    // allow dummy router
    await aggregator.setRouterAllowed(dummyRouter.target, true);
  });

  it('owner is deployer and feeRecipient set', async function () {
    expect(await aggregator.owner()).to.equal(owner.address);
    expect(await aggregator.platformFeeBps()).to.equal(30);
    expect(await aggregator.feeRecipient()).to.equal(feeRecipient.address);
  });

  it('multicall executes and takes fee', async function () {
    const amount = ethers.parseUnits('100', 18);

    // build calldata for dummy router: swapTo(token, to, amount)
    const iface = dummyRouter.interface;
    const calldata = iface.encodeFunctionData('swapTo', [dummyToken.target, aggregator.target, amount]);

    // call multicall as user
    const routers = [dummyRouter.target];
    const calldatas = [calldata];
    const values = [0];

    // user calls multicall -> aggregator will receive tokens from dummy router, take fee, and send remainder to user
    await aggregator.connect(user).multicall(routers, calldatas, values, dummyToken.target, amount, Math.floor(Date.now() / 1000) + 60);

    // compute expected fee and final amounts
    const fee = amount * 30n / 10000n; // 30 bps
    const expectedUserReceive = amount - fee;

    const userBalance = await dummyToken.balanceOf(user.address);
    const feeBalance = await dummyToken.balanceOf(feeRecipient.address);

    expect(userBalance).to.equal(expectedUserReceive);
    expect(feeBalance).to.equal(fee);
  });

  it('rejects router not allowed', async function () {
    const otherDummy = await (await ethers.getContractFactory('DummyRouterV2')).deploy();
    await otherDummy.waitForDeployment();

    const calldata = otherDummy.interface.encodeFunctionData('swapTo', [dummyToken.target, aggregator.target, ethers.parseUnits('1', 18)]);
    await expect(
      aggregator.connect(user).multicall([otherDummy.target], [calldata], [0], dummyToken.target, 1, Math.floor(Date.now() / 1000) + 60)
    ).to.be.revertedWith('AggregatorV2: router not allowed');
  });
});
