const hre = require('hardhat');
require('dotenv').config();

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying with', deployer.address);

  const SimpleAggregator = await hre.ethers.getContractFactory('SimpleAggregator');
  const aggregator = await SimpleAggregator.deploy();
  await aggregator.waitForDeployment();

  console.log('SimpleAggregator deployed to:', await aggregator.getAddress());

  // Example: optionally set some known routers (only if addresses are set via env)
  // const routerAddr = process.env.EXAMPLE_ROUTER;
  // if (routerAddr) {
  //   const tx = await aggregator.setRouterAllowed(routerAddr, true);
  //   await tx.wait();
  //   console.log('Allowed router set:', routerAddr);
  // }

  // Print verification command hint
  console.log('\nVerify (if using Etherscan API):');
  console.log('npx hardhat verify --network <network> ' + (await aggregator.getAddress()));
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
