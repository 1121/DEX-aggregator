const hre = require('hardhat');
require('dotenv').config();

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log('Deploying with', deployer.address);

  const feeRecipient = process.env.FEE_RECIPIENT || deployer.address;
  const platformFeeBps = process.env.PLATFORM_FEE_BPS ? parseInt(process.env.PLATFORM_FEE_BPS) : 30; // 0.3%

  const Aggregator = await hre.ethers.getContractFactory('AggregatorV2');
  const aggregator = await Aggregator.deploy(platformFeeBps, feeRecipient);
  await aggregator.waitForDeployment();

  console.log('AggregatorV2 deployed to:', await aggregator.getAddress());

  // deploy dummy router for convenience in local testing
  const DummyRouter = await hre.ethers.getContractFactory('DummyRouterV2');
  const dummy = await DummyRouter.deploy();
  await dummy.waitForDeployment();
  console.log('DummyRouterV2 deployed to:', await dummy.getAddress());

  // allow dummy router
  const tx = await aggregator.setRouterAllowed(await dummy.getAddress(), true);
  await tx.wait();
  console.log('Allowed dummy router:', await dummy.getAddress());

  // Deploy dummy token and mint to dummy router so it can transfer tokens in tests
  const DummyToken = await hre.ethers.getContractFactory('DummyERC20');
  const token = await DummyToken.deploy('Dummy Token', 'DUM');
  await token.waitForDeployment();
  console.log('DummyToken deployed to:', await token.getAddress());

  const mintTx = await token.mint(await dummy.getAddress(), hre.ethers.parseUnits('10000', 18));
  await mintTx.wait();
  console.log('Minted tokens to dummy router');

  console.log('\\nDone. You can now interact with aggregator in local network.');
  console.log('Aggregator address:', await aggregator.getAddress());
  console.log('Dummy router:', await dummy.getAddress());
  console.log('Dummy token:', await token.getAddress());
}

main().catch((err) => {
  console.error(err);
  process.exitCode = 1;
});
