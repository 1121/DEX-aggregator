const hre = require('hardhat');
require('dotenv').config();

async function main() {
  const addr = process.argv[2];
  if (!addr) {
    console.log('Usage: node scripts/verify.js <contractAddress>');
    process.exit(1);
  }
  try {
    await hre.run('verify:verify', {
      address: addr,
    });
    console.log('Verified', addr);
  } catch (err) {
    console.error('Verify failed:', err.message || err);
  }
}

main();
